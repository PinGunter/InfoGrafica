//
// Created by pingo on 26/10/21.
//

#include <Esfera.h>
Esfera::Esfera(int num_vert_perfil, int num_instancias_perf, float r) {
    radio = r;

}
