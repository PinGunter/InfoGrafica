//
// Created by pingo on 26/10/21.
//

#include "Cono.h"
Cono::Cono(int num_vert_perfil, int num_instancias_perf, float h, float r) {
    altura = h;
    radio = r;
}
