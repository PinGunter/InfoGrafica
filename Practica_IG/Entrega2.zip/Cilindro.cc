//
// Created by pingo on 26/10/21.
//

#include <Cilindro.h>
Cilindro::Cilindro(int num_vert_perfil, int num_instancias_perf, float h, float r) {
    altura = h;
    radio = r;
}
